import { expose } from 'threads/worker';
import { Decrypt } from '@/decrypt';

expose(Decrypt);
